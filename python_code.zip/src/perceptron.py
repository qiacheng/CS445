#Qiacheng Li
#CS445
#HW1

class Perceptron():

    def __init__(self,  bias_weight, weight, label, wx):

        self.bias_weight = bias_weight
        self.weight = weight
        self.label = label
        self.wx = wx


